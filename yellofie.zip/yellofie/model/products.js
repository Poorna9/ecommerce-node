const mongoose = require('mongoose')
const schema = mongoose.Schema

const productSchema = new schema({
    productname:{
        type:String,
        required:true
    },
    price:{
        type:Number,
        required:true
    },
    image:{
        type:String,
        required:true
    }
})

module.exports = productschema = mongoose.model("products",productSchema)
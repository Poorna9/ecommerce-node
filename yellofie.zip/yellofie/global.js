ReE =async function(res,errors){
   return res.json({
        status:"failed",
        message:errors.message        
    })
}

ReS =async function(res,data){
    return res.json({
        status:"success",
        message:data        
    })
}


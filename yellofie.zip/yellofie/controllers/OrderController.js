const orderSchema = require('./../model/OrderModel')
const isEmpty = require('is-empty')
const productSchema = require('./../model/products')

const addOrder = async function(req,res){
    var reqBody = req.body
   var productId = req.params.productId
    var userId = req.user._id
    if(reqBody.quandity===''||reqBody.quandity===undefined){
        return ReE(res,{messaeg:'qyandity field required'})
    }
    productSchema.find({_id:productId}).then(
        product=>{
            if(!isEmpty(product)){
                console.log(product)
               
            }
        }

    )



}

const isEmpty = require('is-empty')

const bcrypt = require('bcryptjs')

const jwt=require('jsonwebtoken')

const keys = require('./../config/config')

const productSchema = require('./../model/products')

//const userValidation = require('./../Validations/UserValidation')

const userSchema = require('./../model/UserModel')


const register = async function(req,res){

  var reqBody=req.body

  const  {isValid,errors} = userValidation.registerInput(req.body)
  
  if(!isValid){

      return ReE(res,{message:errors})

  }
   
  userSchema.findOne({email:reqBody.email}).then(data=>{

    if(!isEmpty(data)){

        return res.json({status:"failed",message:"Email id already exists"})}

      else{
       
            var newUserModel = new userSchema({

              name:reqBody.name,

              email:reqBody.email,

              password:reqBody.password    

            })

            bcrypt.genSalt(10,(err,salt)=>{
              
              if(err)

                {return ReE(res,{message:"error in Hashing"})}

                  bcrypt.hash(newUserModel.password,salt,(err,hash)=>{

                  if(err)

                    {return ReE(res,{message:"error in Hashig"})}

                      newUserModel.password=hash

                      newUserModel.save().then(data=>{

                        return ReS(res,data)

                      }).catch(err=>{return ReE(res,err)})})})
          
           }})
        .catch(err=>{res.json({status:"failed",message:err.message})})
     }

const login = async function(req,res){

  const  {isValid,errors} = userValidation.loginInput(req.body)

  if(!isValid){

      return ReE(res,{message:errors})

  }

  userSchema.findOne({email:req.body.userdata}).then(data=>{


    if(!data){

      userSchema.findOne({phone:req.body.userdata}).then(data=>{

        if(!isEmpty(data)){

          bcrypt.compare(req.body.password,data.password).then(match=>{

            if(match){

            const payload = {id:data.id,name:data.name} 

            jwt.sign(payload , keys.secretOrKey,

                {expiresIn:31556926},

                (err,token)=>{ res.json({status:"success",token:"Bearer "+token,role:data.role})})}

             
            else{

              return ReE(res,{message:"given password or phone/email invalid"})

            }

          })

          .catch(err=>{return ReE(res,err)})

        }

        else{
          
          return ReE(res,{message:"given password or phone/email invalid"})

        }

      }).catch(err=>{

        return ReE(res,err)

      })

    }

    else{

      bcrypt.compare(req.body.password,data.password).then(match=>{
        
        if(match){

          const payload = {id:data.id,name:data.name} 

            jwt.sign(payload , keys.secretOrKey,

                {expiresIn:31556926},

                (err,token)=>{ res.json({status:"success",token:"Bearer "+token,role:data.role})})}
             
        else{

          return ReE(res,{message:"given password or phone/email invalid"})

        }

      })

      .catch(err=>{return ReE(res,err)})

    }

  }).catch(err=>{

    return ReE(res,err)

  })
  
}

const addtocart = async function(req,res){

  productId = req.params.productId,

  userId = req.user._id

  productSchema.findOne({_id:productId}).then(

    data=>{

        if(isEmpty(data)){

          return ReE(res,{message:'item not fount'})

        }

        else
        {

          userSchema.findOne({_id:userId,cart:{$in:[productId]}})
          .then(data=>
            {
              if(isEmpty(data))
              {
                userSchema.updateOne({_id:userId},{$push:{cart:productId}})
                .then(data=>{return ReS(res,data)})
                .catch(err=>{return ReE(res,{message:err.message})})
              }
            
            }
          )
          .catch(err=>{ReE(res,{message:err.message})})
               } }  )
  .catch(err=>{
    console.log(err)
    return ReE(res,{message:err.message})
})
}

const showcart = async function(req,res){
    var userId = req.user._id
    userSchema.find({_id:userId},{_id:0,cart:1})
    .then(cart=>{
      var val = cart[0].cart
        productSchema.find({_id:{$in:val}})
        .then(data=>{return ReS(res,data)})
        .catch(err=>{return ReE(res,{message:err.message})})
    })
    .catch(err=>{
      console.log(err)
      ReE(res,{message:err.message})
    })
}

const deletecart = async function(req,res){
  var userId = req.user._id
  var productId = req.params.productId
  userSchema.update({_id:userId},  { $pull: { cart:productId} },
  { multi: true })
  .then(data=>{ReS(res,data)})
  .catch(err=>{
    console.log(err.message)
    return ReE(res,{message:err.message})})

}



module.exports={
    register:register,
    login:login,
    addtocart:addtocart,
    showcart:showcart,
    deletecart:deletecart
}
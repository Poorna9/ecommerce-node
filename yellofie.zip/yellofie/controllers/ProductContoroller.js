//const productValidation = require('./../Validations/ProductValidation')
const productSchema = require('./../model/products')
const isEmpty = require('is-empty')
const addproducts = async function(req,res){
    if(req.user.role==="A"){
        return ReE(res,{message:"unauthorization you are not an admin"})
    }
    else{
        var reqBody = req.body
        console.log(reqBody)
        const {isValid,errors}=productValidation.addDataInput(reqBody)
        if(!isValid){
            return ReE(res,{message:errors})
        }
        productSchema.findOne({productname:reqBody.productname})
        .then(data=>{if(data){
            data.error = "item exist"
            console.log(data)
            return ReE(res,{message:"item already exist ,Please update item"})
        }
        else{
            const newProductSchema = new productSchema({
                productname:reqBody.productname,
                
                
                price:reqBody.price,
                
                image:reqBody.image
            })
            newProductSchema.save().then(data=>
                {
                    return ReS(res,data)
                }
            ).catch(err=>{return ReE(res,err)})
    
        }
    })
        .catch(err=>{return ReE(res,err)})
        

    }
}

const findProduct = async function(req,res){
    productSchema.findById(req.params.productId).then(data=>{
        return ReS(res,data)
    })
    .catch(err=>{return ReE(res,err)})
}
const updateproducts = async function(req,res){
    var productId = req.params.productId;
    productSchema.findOne({_id:productId}).then(data=>{
        if(!isEmpty(data)){
            productSchema.update({_id:productId},{$set:req.body}).then(data=>{
                return ReS(res,data)
            }).catch(err=>{return ReE(res,err)})
        }else{
            return ReE(res,{message:"invalid Product Id"})
        }
    }).catch(err=>{return ReE(res,err)})
   
}


const findAllProduct = async function(req,res){
    productSchema.find().then(data=>{return ReS(res,data)}).catch(err=>{return ReE(res,err)})
}

const deleteProduct = async function(req,res){
    const productId = req.params.productId
    productSchema.findOne({_id:productId}).then(data=>{
        if(!isEmpty(data)){
            productSchema.deleteOne({_id:productId},{$set:req.body}).then(data=>{
                return ReS(res,data)
            }).catch(err=>{return ReE(res,err)})
        }else{
            return ReE(res,{message:"invalid Product Id"})
        }
    }).catch(err=>{return ReE(res,err)})
}


module.exports = {
    addproducts:addproducts,
    findProduct:findProduct,
    updateproducts:updateproducts,
    findAllProduct:findAllProduct,
    deleteProduct:deleteProduct
}
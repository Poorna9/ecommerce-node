const express = require('express')
const passport = require('passport')
const router = express.Router()
const userControll = require('./../controllers/UserController')
const productController = require('./../controllers/ProductContoroller')
router.post('/register',userControll.register)

router.post('/login',userControll.login)

router.post('/addproducts',passport.authenticate('jwt',{session:false}),productController.addproducts)

router.get('/findProduct/:productId',passport.authenticate('jwt',{session:false}),productController.findProduct)

router.post('/updateproducts/:productId',passport.authenticate('jwt',{session:false}),productController.updateproducts)

router.get('/findallproducts',productController.findAllProduct)

router.delete('/deleteproduct/:productId',passport.authenticate('jwt',{session:false}),productController.deleteProduct)

router.post('/addtocart/:productId',passport.authenticate('jwt',{session:false}),userControll.addtocart)

router.get('/showcart',passport.authenticate('jwt',{session:false}),userControll.showcart)

router.delete('/deletecart/:productId',passport.authenticate('jwt',{session:false}),userControll.deletecart)

module.exports = router
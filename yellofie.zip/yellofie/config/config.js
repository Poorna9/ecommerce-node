module.exports.db = "mongodb://localhost:27017/exam"
module.exports.secretOrKey="secret"
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const express  = require('express')
const app = express()
const db = require('./config/config').db
const passport = require('passport')
const api = require('./routes/api')
const cors = require('cors')
app.use(cors())

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:false}))
require('./global')
require('./config/passport')(passport);

mongoose.connect(db,{useNewUrlParser:true}).then(()=>{
    console.log("mongo connected successfully")
}).catch(err=>{console.log(err)})
mongoose.set('useFindAndModify', false );
app.use('/api',api)

const port = 4000
app.listen(port,()=>{console.log(`system start in ${port}`)})